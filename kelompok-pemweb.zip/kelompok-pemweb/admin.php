<?php
// File: admin.php
// Simpan di: C:/xampp/htdocs/movie-review/admin.php
// Akses: http://localhost/movie-review/admin.php
// DASHBOARD ADMIN ALL-IN-ONE untuk mengelola film, rating, dan reviews

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database Configuration
$host = '127.0.0.1';
$dbname = 'movie_review_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database Connection Error: " . $e->getMessage());
}

// Buat folder uploads jika belum ada
$uploadDirs = ['uploads', 'uploads/posters', 'uploads/videos'];
foreach ($uploadDirs as $dir) {
    if (!file_exists($dir)) mkdir($dir, 0777, true);
}

$message = '';
$messageType = '';
$action = $_GET['action'] ?? 'dashboard';

// ==================== PROSES ACTIONS ====================

// CREATE MOVIE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_movie'])) {
    $posterPath = '';
    
    if (isset($_FILES['poster']) && $_FILES['poster']['error'] === UPLOAD_ERR_OK) {
        $posterName = time() . '_' . basename($_FILES['poster']['name']);
        $posterTarget = 'uploads/posters/' . $posterName;
        if (move_uploaded_file($_FILES['poster']['tmp_name'], $posterTarget)) {
            $posterPath = $posterTarget;
        }
    }
    
    $sql = "INSERT INTO movies (title, original_title, release_year, duration, genre, director, synopsis, poster, trailer_url, created_at) 
            VALUES (:title, :original_title, :release_year, :duration, :genre, :director, :synopsis, :poster, :trailer_url, NOW())";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':title' => $_POST['title'],
        ':original_title' => $_POST['original_title'],
        ':release_year' => $_POST['release_year'],
        ':duration' => $_POST['duration'],
        ':genre' => $_POST['genre'],
        ':director' => $_POST['director'],
        ':synopsis' => $_POST['synopsis'],
        ':poster' => $posterPath,
        ':trailer_url' => $_POST['trailer_url']
    ]);
    
    $message = "✅ Film '{$_POST['title']}' berhasil ditambahkan!";
    $messageType = 'success';
}

// UPDATE MOVIE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_movie'])) {
    $movieId = $_POST['movie_id'];
    $posterPath = $_POST['existing_poster'];
    
    if (isset($_FILES['poster']) && $_FILES['poster']['error'] === UPLOAD_ERR_OK) {
        $posterName = time() . '_' . basename($_FILES['poster']['name']);
        $posterTarget = 'uploads/posters/' . $posterName;
        if (move_uploaded_file($_FILES['poster']['tmp_name'], $posterTarget)) {
            $posterPath = $posterTarget;
            // Delete old poster
            if (!empty($_POST['existing_poster']) && file_exists($_POST['existing_poster'])) {
                unlink($_POST['existing_poster']);
            }
        }
    }
    
    $sql = "UPDATE movies SET 
            title = :title,
            original_title = :original_title,
            release_year = :release_year,
            duration = :duration,
            genre = :genre,
            director = :director,
            synopsis = :synopsis,
            poster = :poster,
            trailer_url = :trailer_url,
            updated_at = NOW()
            WHERE id = :id";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':title' => $_POST['title'],
        ':original_title' => $_POST['original_title'],
        ':release_year' => $_POST['release_year'],
        ':duration' => $_POST['duration'],
        ':genre' => $_POST['genre'],
        ':director' => $_POST['director'],
        ':synopsis' => $_POST['synopsis'],
        ':poster' => $posterPath,
        ':trailer_url' => $_POST['trailer_url'],
        ':id' => $movieId
    ]);
    
    $message = "✅ Film berhasil diupdate!";
    $messageType = 'success';
}

// DELETE MOVIE
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $movieId = (int)$_GET['delete'];
    
    // Get poster path to delete file
    $stmt = $pdo->prepare("SELECT poster FROM movies WHERE id = :id");
    $stmt->execute([':id' => $movieId]);
    $movie = $stmt->fetch();
    
    // Delete poster file
    if ($movie && !empty($movie['poster']) && file_exists($movie['poster'])) {
        unlink($movie['poster']);
    }
    
    // Delete movie
    $stmt = $pdo->prepare("DELETE FROM movies WHERE id = :id");
    $stmt->execute([':id' => $movieId]);
    
    $message = "✅ Film berhasil dihapus!";
    $messageType = 'success';
}

// DELETE REVIEW
if (isset($_GET['delete_review']) && is_numeric($_GET['delete_review'])) {
    $reviewId = (int)$_GET['delete_review'];
    $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = :id");
    $stmt->execute([':id' => $reviewId]);
    
    $message = "✅ Review berhasil dihapus!";
    $messageType = 'success';
}

// ==================== FETCH DATA ====================

// Get all movies
$moviesStmt = $pdo->query("SELECT m.*, 
    (SELECT COUNT(*) FROM reviews WHERE movie_id = m.id) as review_count,
    (SELECT AVG(rating) FROM reviews WHERE movie_id = m.id) as avg_rating
    FROM movies m ORDER BY m.id DESC");
$movies = $moviesStmt->fetchAll();

// Get all reviews with movie info
$reviewsStmt = $pdo->query("SELECT r.*, m.title as movie_title, u.username, u.full_name 
    FROM reviews r 
    LEFT JOIN movies m ON r.movie_id = m.id
    LEFT JOIN users u ON r.user_id = u.id
    ORDER BY r.created_at DESC LIMIT 50");
$reviews = $reviewsStmt->fetchAll();

// Get stats
$totalMovies = count($movies);
$totalReviews = $pdo->query("SELECT COUNT(*) FROM reviews")->fetchColumn();
$avgRating = $pdo->query("SELECT AVG(rating) FROM reviews")->fetchColumn();

// Get movie for edit
$editMovie = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM movies WHERE id = :id");
    $stmt->execute([':id' => $_GET['id']]);
    $editMovie = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Movie Review</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 20px;
            overflow-y: auto;
        }
        
        .sidebar h1 {
            font-size: 1.5em;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-menu li {
            margin-bottom: 10px;
        }
        
        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .nav-menu a:hover, .nav-menu a.active {
            background: rgba(255,255,255,0.2);
        }
        
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }
        
        .header {
            background: white;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h2 {
            color: #333;
            font-size: 1.8em;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-warning {
            background: #ffc107;
            color: #333;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 13px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .stat-card h3 {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 10px;
        }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 30px;
            margin-bottom: 20px;
        }
        
        .card h3 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.3em;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
            transition: border 0.3s;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #e0e0e0;
        }
        
        table td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        table tr:hover {
            background: #f8f9fa;
        }
        
        .movie-poster-thumb {
            width: 60px;
            height: 90px;
            object-fit: cover;
            border-radius: 6px;
        }
        
        .rating-badge {
            background: #ffc107;
            color: #333;
            padding: 4px 10px;
            border-radius: 12px;
            font-weight: bold;
            font-size: 0.9em;
        }
        
        .message {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .poster-preview {
            max-width: 200px;
            margin-top: 10px;
            border-radius: 8px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            table {
                font-size: 13px;
            }
            
            .btn {
                padding: 8px 15px;
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h1>🎬 Admin Panel</h1>
        <ul class="nav-menu">
            <li><a href="?action=dashboard" class="<?php echo $action === 'dashboard' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i> Dashboard
            </a></li>
            <li><a href="?action=movies" class="<?php echo $action === 'movies' ? 'active' : ''; ?>">
                <i class="fas fa-film"></i> Kelola Film
            </a></li>
            <li><a href="?action=add" class="<?php echo $action === 'add' ? 'active' : ''; ?>">
                <i class="fas fa-plus"></i> Tambah Film
            </a></li>
            <li><a href="?action=reviews" class="<?php echo $action === 'reviews' ? 'active' : ''; ?>">
                <i class="fas fa-star"></i> Reviews
            </a></li>
            <li><a href="user.html" target="_blank">
                <i class="fas fa-external-link-alt"></i> Lihat Website
            </a></li>
        </ul>
    </div>
    
    <div class="main-content">
        <?php if ($message): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($action === 'dashboard'): ?>
            <div class="header">
                <h2>📊 Dashboard</h2>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Film</h3>
                    <div class="stat-number"><?php echo $totalMovies; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Reviews</h3>
                    <div class="stat-number"><?php echo $totalReviews; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Rating Rata-rata</h3>
                    <div class="stat-number"><?php echo $avgRating ? number_format($avgRating, 1) : '0.0'; ?></div>
                </div>
            </div>
            
            <div class="card">
                <h3>Film Terbaru</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Poster</th>
                            <th>Judul</th>
                            <th>Tahun</th>
                            <th>Rating</th>
                            <th>Reviews</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach(array_slice($movies, 0, 10) as $movie): ?>
                        <tr>
                            <td>
                                <?php if (!empty($movie['poster'])): ?>
                                    <img src="<?php echo htmlspecialchars($movie['poster']); ?>" class="movie-poster-thumb" alt="">
                                <?php else: ?>
                                    <div style="width:60px;height:90px;background:#667eea;border-radius:6px;display:flex;align-items:center;justify-content:center;color:white;">🎬</div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo htmlspecialchars($movie['title']); ?></strong></td>
                            <td><?php echo htmlspecialchars($movie['release_year']); ?></td>
                            <td><span class="rating-badge">⭐ <?php echo $movie['avg_rating'] ? number_format($movie['avg_rating'], 1) : '0.0'; ?></span></td>
                            <td><?php echo $movie['review_count']; ?> reviews</td>
                            <td>
                                <a href="?action=edit&id=<?php echo $movie['id']; ?>" class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
        <?php elseif ($action === 'movies'): ?>
            <div class="header">
                <h2>🎥 Kelola Film</h2>
                <a href="?action=add" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Tambah Film
                </a>
            </div>
            
            <div class="card">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Poster</th>
                            <th>Judul</th>
                            <th>Genre</th>
                            <th>Tahun</th>
                            <th>Rating</th>
                            <th>Reviews</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($movies as $movie): ?>
                        <tr>
                            <td><?php echo $movie['id']; ?></td>
                            <td>
                                <?php if (!empty($movie['poster'])): ?>
                                    <img src="<?php echo htmlspecialchars($movie['poster']); ?>" class="movie-poster-thumb" alt="">
                                <?php else: ?>
                                    <div style="width:60px;height:90px;background:#667eea;border-radius:6px;display:flex;align-items:center;justify-content:center;color:white;">🎬</div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($movie['title']); ?></strong>
                                <?php if (!empty($movie['original_title'])): ?>
                                    <br><small style="color:#999;"><?php echo htmlspecialchars($movie['original_title']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($movie['genre']); ?></td>
                            <td><?php echo htmlspecialchars($movie['release_year']); ?></td>
                            <td><span class="rating-badge">⭐ <?php echo $movie['avg_rating'] ? number_format($movie['avg_rating'], 1) : '0.0'; ?></span></td>
                            <td><?php echo $movie['review_count']; ?></td>
                            <td>
                                <a href="?action=edit&id=<?php echo $movie['id']; ?>" class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="?delete=<?php echo $movie['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus film ini?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
        <?php elseif ($action === 'add' || $action === 'edit'): ?>
            <div class="header">
                <h2><?php echo $action === 'edit' ? '✏️ Edit Film' : '➕ Tambah Film Baru'; ?></h2>
            </div>
            
            <div class="card">
                <form method="POST" enctype="multipart/form-data">
                    <?php if ($action === 'edit'): ?>
                        <input type="hidden" name="movie_id" value="<?php echo $editMovie['id']; ?>">
                        <input type="hidden" name="existing_poster" value="<?php echo $editMovie['poster']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label>Judul Film *</label>
                        <input type="text" name="title" required value="<?php echo $editMovie['title'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Judul Asli</label>
                        <input type="text" name="original_title" value="<?php echo $editMovie['original_title'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Tahun Rilis *</label>
                            <input type="number" name="release_year" required value="<?php echo $editMovie['release_year'] ?? date('Y'); ?>">
                        </div>
                        <div class="form-group">
                            <label>Durasi (menit)</label>
                            <input type="number" name="duration" value="<?php echo $editMovie['duration'] ?? ''; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Genre *</label>
                        <input type="text" name="genre" required placeholder="Contoh: Horror, Thriller, Drama" value="<?php echo $editMovie['genre'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Sutradara</label>
                        <input type="text" name="director" value="<?php echo $editMovie['director'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Sinopsis *</label>
                        <textarea name="synopsis" required><?php echo $editMovie['synopsis'] ?? ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>Upload Poster</label>
                        <input type="file" name="poster" accept="image/*" onchange="previewImage(this)">
                        <?php if ($action === 'edit' && !empty($editMovie['poster'])): ?>
                            <img src="<?php echo $editMovie['poster']; ?>" class="poster-preview" id="preview">
                        <?php else: ?>
                            <img id="preview" class="poster-preview" style="display:none;">
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>URL Trailer YouTube</label>
                        <input type="url" name="trailer_url" placeholder="https://youtube.com/watch?v=..." value="<?php echo $editMovie['trailer_url'] ?? ''; ?>">
                    </div>
                    
                    <button type="submit" name="<?php echo $action === 'edit' ? 'update_movie' : 'create_movie'; ?>" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?php echo $action === 'edit' ? 'Update Film' : 'Simpan Film'; ?>
                    </button>
                    <a href="?action=movies" class="btn btn-danger">Batal</a>
                </form>
            </div>
            
        <?php elseif ($action === 'reviews'): ?>
            <div class="header">
                <h2>⭐ Semua Reviews</h2>
            </div>
            
            <div class="card">
                <table>
                    <thead>
                        <tr>
                            <th>Film</th>
                            <th>User</th>
                            <th>Rating</th>
                            <th>Review</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($reviews) > 0): ?>
                            <?php foreach($reviews as $review): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($review['movie_title']); ?></strong></td>
                                <td><?php echo htmlspecialchars($review['full_name'] ?? $review['username'] ?? 'Anonymous'); ?></td>
                                <td><span class="rating-badge">⭐ <?php echo number_format($review['rating'], 1); ?></span></td>
                                <td><?php echo substr(htmlspecialchars($review['review_text']), 0, 100); ?>...</td>
                                <td><?php echo date('d/m/Y', strtotime($review['created_at'])); ?></td>
                                <td>
                                    <a href="?action=reviews&delete_review=<?php echo $review['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus review ini?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align:center;padding:40px;color:#999;">Belum ada review</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        function previewImage(input) {
            const preview = document.getElementById('preview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>
</html>