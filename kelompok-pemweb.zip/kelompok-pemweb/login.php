<?php
require_once(__DIR__ . "/config.php");
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        echo "Email dan password harus diisi!";
        exit;
    }

    // Ambil user berdasarkan email
    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

  if ($row = mysqli_fetch_assoc($result)) {
    var_dump($password);
    var_dump($row['password_hash']);
    var_dump(password_verify($password, $row['password_hash']));
    exit;
}
 else {
            echo "⚠️ Password salah!";
        }
    } else {
        echo "❌ Email tidak ditemukan!";
    }
}
?>
