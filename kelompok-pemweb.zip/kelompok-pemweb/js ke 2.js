/**
 * Fungsi untuk menyaring (filter) kartu film berdasarkan input pencarian.
 * Fungsi ini dipanggil secara otomatis setiap kali pengguna mengetik di kolom search.
 */
function filterMovies() {
    // 1. Dapatkan elemen input pencarian menggunakan ID
    const searchInput = document.getElementById('movie-search-input');
    
    // Ambil nilai input dan ubah ke huruf kecil untuk pencarian case-insensitive
    const searchTerm = searchInput.value.toLowerCase();

    // 2. Dapatkan SEMUA kartu film di seluruh halaman, 
    // terlepas dari bagian (grid) mana pun mereka berada.
    // Asumsi: Setiap kartu film menggunakan class "movie-card"
    const movieCards = document.querySelectorAll('.movie-card');

    // 3. Iterasi (ulangi) pada setiap kartu film yang ditemukan
    movieCards.forEach(card => {
        // Dapatkan elemen yang berisi judul film di dalam kartu.
        // Asumsi: Judul film berada di dalam elemen dengan class "movie-title"
        const titleElement = card.querySelector('.movie-title');
        
        if (titleElement) {
            const title = titleElement.textContent.toLowerCase();

            // 4. Periksa apakah judul film mengandung (includes) istilah pencarian.
            if (title.includes(searchTerm)) {
                // Jika cocok, tampilkan kartu.
                // Menggunakan '' akan mengembalikan ke tampilan default (misalnya flex/grid/block)
                card.style.display = ''; 
            } else {
                // Jika tidak cocok, sembunyikan kartu.
                card.style.display = 'none'; 
            }
        }
    });
}