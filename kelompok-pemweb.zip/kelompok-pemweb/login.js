document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const rememberMe = document.getElementById('rememberMe');
    const errorAlert = document.getElementById('errorAlert');
    const successAlert = document.getElementById('successAlert');

    // Load email tersimpan jika "Ingat Saya" aktif
    const savedEmail = localStorage.getItem('cineScopeRememberMe');
    if (savedEmail) {
        emailInput.value = savedEmail;
        rememberMe.checked = true;
    }

    // Handle form submit
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();  // Cegah reload halaman

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();
        const remember = rememberMe.checked;

        // Validasi sederhana
        if (!email || !password) {
            showAlert(errorAlert, 'Email dan password harus diisi!');
            return;
        }

        if (!isValidEmail(email)) {
            showAlert(errorAlert, 'Format email tidak valid!');
            return;
        }

        // Simulasi login (dummy: email valid + password "password123")
        // Nanti ganti dengan fetch ke backend: fetch('/api/login', { method: 'POST', body: JSON.stringify({email, password}) })
        const validPassword = 'password123';  // Dummy password untuk test
        if (password === validPassword) {
            // Sukses: Simpan ke localStorage
            localStorage.setItem('cineScopeLoggedIn', 'true');
            localStorage.setItem('cineScopeEmail', email);
            if (remember) {
                localStorage.setItem('cineScopeRememberMe', email);
            } else {
                localStorage.removeItem('cineScopeRememberMe');
            }

            showAlert(successAlert, 'Login berhasil! Redirecting...');
            
            // Redirect ke index.html setelah 1.5 detik
            setTimeout(() => {
                window.location.href = 'user.html';
            }, 1500);
        } else {
            // Gagal
            showAlert(errorAlert, 'Email atau password salah! Coba lagi.');
            passwordInput.value = '';  // Clear password
        }
    });

    // Fungsi validasi email
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Fungsi tampilkan alert
    function showAlert(alertElement, message) {
        // Hide semua alert dulu
        errorAlert.style.display = 'none';
        successAlert.style.display = 'none';
        
        // Set message dan tampilkan
        alertElement.textContent = message;
        alertElement.style.display = 'flex';
        
        // Auto hide setelah 5 detik (opsional)
        setTimeout(() => {
            alertElement.style.display = 'none';
        }, 5000);
    }

    // Handle "Lupa Password" (simulasi)
    document.querySelector('.forgot-link').addEventListener('click', function(e) {
        e.preventDefault();
        alert('Fitur lupa password akan segera hadir. Hubungi support@cinescope.com');
    });

   