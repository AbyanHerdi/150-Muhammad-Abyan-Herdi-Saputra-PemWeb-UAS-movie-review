// ===== DATA FILM UTAMA =====
const moviesData = [
  {
    id: 1,
    title: "Sore",
    year: "2025",
    genre: "Drama Romantis-Fantasi Ilmiah",
    rating: 8.1,
    image: "sore.jpg",
    description: "Sebuah cerita tentang cinta yang melampaui dimensi",
    releaseDate: "10 Juli 2025"
  },
  {
    id: 2,
    title: "Petaka Gunung Gede",
    year: "2025",
    genre: "Horor-Petualangan",
    rating: 7.9,
    image: "petaka-gunung-gede.jpg",
    description: "Petualangan menakutkan di gunung yang penuh misteri",
    releaseDate: "19 Juni 2025"
  },
  {
    id: 3,
    title: "Dilan 1990",
    year: "2018",
    genre: "Documentary, Drama",
    rating: 8.4,
    image: "dilan-1990.jpg",
    description: "Kisah cinta legendaris di era 90-an",
    releaseDate: "25 Januari 2018"
  },
  {
    id: 4,
    title: "Rest Area",
    year: "2025",
    genre: "Aksi-Thriller",
    rating: 7.2,
    image: "rest-area.jpg",
    description: "Malam mencekam di rest area yang terisolasi.",
    releaseDate: "5 September 2025"
  },
  {
    id: 5,
    title: "Tukar Takdir",
    year: "2024",
    genre: "Sci-Fi-Drama",
    rating: 8.5,
    image: "tukar-takdir.jpg",
    description: "Ketika sebuah aplikasi bisa menukar nasib hidupmu",
    releaseDate: "1 Desember 2024"
  },
  {
    id: 6,
    title: "Rangga & Cinta",
    year: "2002",
    genre: "Drama-Romantis",
    rating: 8.0,
    image: "rangga-cinta.jpg",
    description: "Adaptasi dari kisah Rangga dan Cinta di tahun 2002",
    releaseDate: "7 Februari 2002"
  }
];

// ===== KONFIGURASI LOCAL STORAGE UNTUK SETIAP FILM =====
const MOVIE_CONFIGS = [
  { title: "Dilan 1990", storageKey: "dilan1990Reviews", type: "array" },
  { title: "Rangga & Cinta", storageKey: "ranggaCintaReviews", type: "array" },
  { title: "Rest Area", storageKey: "restAreaReviews", type: "array" },
  { title: "Tukar Takdir", storageKey: "tukarTakdirReviews", type: "array" },
  { title: "Sore", storageKey: "movieReviews", subKey: "Sore", type: "object" },
  { title: "Petaka Gunung Gede", storageKey: "movieTrendingData", subKey: "Petaka Gunung Gede", type: "object" }
];

// ==========================================================
// 🧮 PERBARUI RATING FILM BERDASARKAN ULASAN
// ==========================================================
function updateMovieRatingsFromReviews() {
  MOVIE_CONFIGS.forEach(config => {
    let avgRating = 0;
    let count = 0;

    try {
      const data = JSON.parse(localStorage.getItem(config.storageKey));

      if (config.type === "array" && Array.isArray(data)) {
        count = data.length;
        if (count > 0) {
          const total = data.reduce((sum, review) => sum + (review.rating || 0), 0);
          avgRating = total / count;
        }
      } else if (config.type === "object" && config.subKey && data && data[config.subKey]) {
        avgRating = data[config.subKey].rating || 0;
        count = data[config.subKey].count || 0;
      }
    } catch (e) {
      console.warn("Gagal membaca data review untuk:", config.title);
    }

    const movie = moviesData.find(m => m.title === config.title);
    if (movie && count > 0) {
      const newRating = ((movie.rating * 1) + (avgRating * count)) / (count + 1);
      movie.rating = parseFloat(newRating.toFixed(1));
    }
  });
}

// ==========================================================
// 🚀 HITUNG DAN URUTKAN TRENDING BERDASARKAN ULASAN
// ==========================================================
function calculateTrendingMetrics() {
  let allMetrics = {};

  MOVIE_CONFIGS.forEach(movie => {
    let rating = 0;
    let count = 0;

    try {
      const data = JSON.parse(localStorage.getItem(movie.storageKey));
      if (movie.type === "array" && data) {
        const reviews = data;
        count = reviews.length;
        if (count > 0) {
          const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
          rating = totalRating / count;
        }
      } else if (movie.type === "object" && movie.subKey && data && data[movie.subKey]) {
        rating = data[movie.subKey].rating || 0;
        count = data[movie.subKey].count || 0;
      }
    } catch (e) {}

    let pageLink = movie.title.toLowerCase().replaceAll(" ", "_").replaceAll("&", "and") + ".html";
    if (movie.title === "Rangga & Cinta") pageLink = "rangga & cinta.html";
    if (movie.title === "Dilan 1990") pageLink = "dilan 1990.html";
    if (movie.title === "Sore") pageLink = "film.sore.html";

    allMetrics[movie.title] = {
      title: movie.title,
      rating: parseFloat(rating.toFixed(1)),
      count: count,
      page: pageLink
    };
  });

  return Object.values(allMetrics);
}

// ==========================================================
// 🔥 URUTKAN TRENDING: ULASAN TERBANYAK → RATING TERTINGGI
// ==========================================================
function getTrendingFilms(filmsData) {
  const MIN_REVIEW_COUNT = 1;
  const MIN_RATING = 0.0;
  const MAX_TRENDING_SLOTS = 5;

  return filmsData
    .filter(film => film.count >= MIN_REVIEW_COUNT && film.rating >= MIN_RATING)
    .sort((a, b) => {
      // 1️⃣ Ulasan terbanyak lebih diutamakan
      if (b.count !== a.count) return b.count - a.count;
      // 2️⃣ Kalau ulasan sama, rating tinggi yang menang
      return b.rating - a.rating;
    })
    .slice(0, MAX_TRENDING_SLOTS);
}

// ==========================================================
// 🧱 RENDER LISTA FILM TRENDING
// ==========================================================
function renderTrending(trendingFilms) {
  const trendingListContainer = document.getElementById('trendingList');
  if (!trendingListContainer) return;

  trendingListContainer.innerHTML = '';

  if (trendingFilms.length === 0) {
    trendingListContainer.innerHTML = `
      <div class="info-message-trending" style="padding: 20px; text-align: center; background: #1f1f1f; border-radius: 8px;">
        <i class="fas fa-chart-line" style="color: #e50914;"></i> Belum ada film yang memenuhi kriteria trending.
      </div>`;
    return;
  }

  trendingFilms.forEach((film, index) => {
    const movieData = moviesData.find(m => m.title === film.title);
    const posterImage = movieData ? movieData.image : "default.jpg";
    const badge = `<div class="trending-badge" style="position:absolute;top:5px;left:5px;background:#e50914;color:#fff;padding:3px 8px;border-radius:5px;font-size:12px;font-weight:700;z-index:10;">Trending #${index + 1}</div>`;

    const filmCard = document.createElement('div');
    filmCard.className = 'movie-card';
    filmCard.style.position = 'relative';
    filmCard.innerHTML = `
      ${badge}
      <a href="${film.page}">
        <img src="images/${posterImage}" alt="${film.title}" class="movie-poster">
      </a>
      <div class="movie-meta">
        <div class="movie-title"><a href="${film.page}">${film.title}</a></div>
        <div class="movie-rating"><i class="fas fa-star" style="color:#ffc107;"></i> ${film.rating.toFixed(1)}/5 <span class="review-count">(${film.count} Ulasan)</span></div>
      </div>`;
    trendingListContainer.appendChild(filmCard);
  });
}

// ==========================================================
// 🔍 FUNGSI PENCARIAN
// ==========================================================
function renderMovieCards(containerId, filmsArray) {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = '';

  if (filmsArray.length === 0) {
    container.innerHTML = '<p class="info-message-search">❌ Tidak ada film yang ditemukan.</p>';
    return;
  }

  filmsArray.forEach(movie => {
    const config = MOVIE_CONFIGS.find(c => c.title === movie.title);
    let pageLink = config ? config.page : movie.title.toLowerCase().replaceAll(" ", "_") + ".html";

    const filmCard = document.createElement('div');
    filmCard.className = 'movie-card';
    filmCard.innerHTML = `
      <a href="${pageLink}">
        <img src="images/${movie.image}" alt="Poster Film ${movie.title}" class="movie-poster">
      </a>
      <div class="movie-meta">
        <div class="movie-title"><a href="${pageLink}">${movie.title}</a></div>
        <div class="movie-genre">${movie.genre}</div>
        <div class="movie-rating"><i class="fas fa-star" style="color:#ffc107;"></i> ${movie.rating.toFixed(1)}/10</div>
      </div>`;
    container.appendChild(filmCard);
  });
}

function initializeSearch() {
  const searchInput = document.querySelector('.search-input');
  const searchBtn = document.querySelector('.search-btn');
  renderMovieCards('recommendedList', moviesData);

  function performSearch() {
    const query = searchInput.value.toLowerCase().trim();
    if (query === "") {
      renderMovieCards('recommendedList', moviesData);
      return;
    }

    const filteredMovies = moviesData.filter(movie =>
      movie.title.toLowerCase().includes(query) ||
      movie.genre.toLowerCase().includes(query) ||
      movie.description.toLowerCase().includes(query)
    );
    renderMovieCards('recommendedList', filteredMovies);
  }

  if (searchInput) searchInput.addEventListener('keyup', performSearch);
  if (searchBtn) searchBtn.addEventListener('click', e => {
    e.preventDefault();
    performSearch();
  });
}

// ==========================================================
// 🔄 SAAT HALAMAN DIMUAT
// ==========================================================
document.addEventListener("DOMContentLoaded", function() {
  updateMovieRatingsFromReviews();

  const filmMetrics = calculateTrendingMetrics();
  const trendingFilms = getTrendingFilms(filmMetrics);
  renderTrending(trendingFilms);

  initializeSearch();

  const addBtn = document.getElementById("btnAddDummy");
  const clearBtn = document.getElementById("btnClearData");

  if (addBtn) {
    addBtn.addEventListener("click", function() {
      localStorage.setItem("tukarTakdirReviews", JSON.stringify([
        { rating: 5 }, { rating: 5 }, { rating: 4 }, { rating: 5 }, { rating: 5 }, { rating: 4 }, { rating: 5 }, { rating: 5 }, { rating: 4 }, { rating: 5 }
      ]));
      localStorage.setItem("dilan1990Reviews", JSON.stringify([
        { rating: 4 }, { rating: 5 }, { rating: 4 }, { rating: 5 }
      ]));
      localStorage.setItem("restAreaReviews", JSON.stringify([
        { rating: 3 }, { rating: 4 }, { rating: 3 }, { rating: 4 }, { rating: 3 }
      ]));
      alert("✅ Data ulasan dummy berhasil ditambahkan!\nSilakan refresh halaman untuk melihat hasilnya.");
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener("click", function() {
      localStorage.clear();
      alert("🧹 Semua data ulasan dihapus!\nSilakan refresh halaman.");
    });
  }

  console.log("✅ script.js berhasil dijalankan tanpa error!");
});
